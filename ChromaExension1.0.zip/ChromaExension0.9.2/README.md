Version 0.9.2
============

> A temp fix to allow the player heads to show images once again.
