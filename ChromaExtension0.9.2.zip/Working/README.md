ChromaExtension
============

Hey there, if you are trying to steal you should know that this projects is open source and licensed under the MIT license. Do what you want. 
If you have any questions I would be more than happy to help - me@luke.sx